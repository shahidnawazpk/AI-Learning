import { useAuth } from "@/hooks/use-auth";
import { useQuizzes } from "@/hooks/use-quiz";
import { QuizForm } from "@/components/quiz-form";
import { Achievements } from "@/components/achievements";
import { AIChat } from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { LogOut } from "lucide-react";
import { Question } from "@shared/schema";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { data: quizzes, isLoading } = useQuizzes();

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="border-b bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-2xl font-bold">AI Quiz Master</h1>
          <Button
            variant="ghost"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="space-y-8">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="new-quiz">New Quiz</TabsTrigger>
            <TabsTrigger value="ai-chat">AI Tutor</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <div className="grid md:grid-cols-2 gap-8">
              <Achievements
                achievements={user.achievements}
                totalScore={user.totalScore}
                quizzesTaken={user.quizzesTaken}
              />

              <Card>
                <CardHeader>
                  <CardTitle>Recent Quizzes</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <p>Loading quizzes...</p>
                  ) : (
                    <div className="space-y-4">
                      {quizzes?.map((quiz) => {
                        const questions = quiz.questions as Question[];
                        return (
                          <Link key={quiz.id} href={`/quiz/${quiz.id}`}>
                            <div className="p-4 bg-accent/10 rounded-lg cursor-pointer hover:bg-accent/20 transition">
                              <h3 className="font-medium">{quiz.subject}</h3>
                              <p className="text-sm text-muted-foreground">
                                Score: {quiz.score} / {questions.length}
                              </p>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="new-quiz">
            <div className="max-w-md mx-auto">
              <QuizForm />
            </div>
          </TabsContent>

          <TabsContent value="ai-chat">
            <div className="max-w-2xl mx-auto">
              <AIChat />
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}