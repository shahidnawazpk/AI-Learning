import { useQuiz } from "@/hooks/use-quiz";
import { useRoute, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QuizQuestion } from "@/components/quiz-question";
import { Loader2, Home, RotateCcw } from "lucide-react";
import { Question } from "@shared/schema";

export default function ResultsPage() {
  const [, params] = useRoute("/results/:id");
  const [, setLocation] = useLocation();
  const quizId = params ? parseInt(params.id) : 0;
  const { data: quiz, isLoading } = useQuiz(quizId);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!quiz || !quiz.completed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-6">
          <h2 className="text-xl font-semibold">Quiz not found</h2>
          <Button
            className="mt-4"
            onClick={() => setLocation("/")}
          >
            Return Home
          </Button>
        </Card>
      </div>
    );
  }

  const questions = quiz.questions as Question[];
  const answers = quiz.answers as string[];

  const correctAnswers = questions.reduce((acc: number, q: Question, i: number) => {
    return acc + (q.correctAnswer === answers[i] ? 1 : 0);
  }, 0);

  const percentage = Math.round((correctAnswers / questions.length) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-2xl mx-auto space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Quiz Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">{quiz.subject}</h2>
                <span className="text-lg font-medium">
                  Score: {correctAnswers} / {questions.length} ({percentage}%)
                </span>
              </div>

              <div className="h-4 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${percentage}%` }}
                />
              </div>

              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">Total Questions</p>
                  <p className="text-2xl font-bold">{questions.length}</p>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">Correct</p>
                  <p className="text-2xl font-bold text-green-600">{correctAnswers}</p>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">Incorrect</p>
                  <p className="text-2xl font-bold text-red-600">
                    {questions.length - correctAnswers}
                  </p>
                </div>
              </div>

              <div className="flex gap-4 justify-center mt-6">
                <Button onClick={() => setLocation("/")} variant="outline">
                  <Home className="h-4 w-4 mr-2" />
                  Home
                </Button>
                <Button onClick={() => setLocation("/new-quiz")}>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Take Another Quiz
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <h3 className="text-xl font-semibold">Review Questions</h3>
          {questions.map((question, index) => (
            <QuizQuestion
              key={index}
              question={question}
              selectedAnswer={answers[index]}
              onAnswer={() => {}}
              showCorrect
            />
          ))}
        </div>
      </div>
    </div>
  );
}