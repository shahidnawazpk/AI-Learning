import { useState } from "react";
import { useQuiz, useSubmitQuiz } from "@/hooks/use-quiz";
import { QuizQuestion } from "@/components/quiz-question";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useRoute, useLocation } from "wouter";
import { Loader2, Home } from "lucide-react";
import { Question } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function QuizPage() {
  const [, params] = useRoute("/quiz/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const quizId = params ? parseInt(params.id) : 0;

  const { data: quiz, isLoading, error } = useQuiz(quizId);
  const submitQuiz = useSubmitQuiz(quizId);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (error || !quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-6 max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-center">Quiz Not Found</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center text-muted-foreground">
              {error?.message || "This quiz might have been deleted or is no longer available."}
            </p>
            <Button
              className="w-full"
              onClick={() => setLocation("/")}
            >
              <Home className="h-4 w-4 mr-2" />
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (quiz.completed) {
    setLocation(`/results/${quiz.id}`);
    return null;
  }

  const questions = quiz.questions as Question[];
  const question = questions[currentQuestion];

  async function handleAnswer(answer: string) {
    try {
      const newAnswers = [...answers];
      newAnswers[currentQuestion] = answer;
      setAnswers(newAnswers);

      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        const submissionData = questions.map((_, i) => ({
          questionId: i,
          selectedAnswer: newAnswers[i],
        }));
        await submitQuiz.mutateAsync(submissionData);
        setLocation(`/results/${quiz.id}`);
      }
    } catch (error: any) {
      toast({
        title: "Failed to submit answer",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">{quiz.subject} Quiz</h1>
          <span className="text-sm text-muted-foreground">
            Question {currentQuestion + 1} of {questions.length}
          </span>
        </div>

        <div className="relative pt-2">
          <div className="h-2 bg-muted rounded-full">
            <div
              className="h-full bg-primary rounded-full transition-all"
              style={{
                width: `${((currentQuestion + 1) / questions.length) * 100}%`,
              }}
            />
          </div>
        </div>

        <QuizQuestion
          question={question}
          selectedAnswer={answers[currentQuestion]}
          onAnswer={handleAnswer}
        />
      </div>
    </div>
  );
}