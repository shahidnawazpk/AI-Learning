import { useQuery, useMutation } from "@tanstack/react-query";
import { Quiz, QuizSettings, QuizAnswer } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useCreateQuiz() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (settings: QuizSettings) => {
      const res = await apiRequest("POST", "/api/quiz", settings);
      return res.json() as Promise<Quiz>;
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create quiz",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useQuiz(id: number) {
  return useQuery<Quiz, Error>({
    queryKey: [`/api/quiz/${id}`],
    enabled: !!id,
  });
}

export function useQuizzes() {
  return useQuery<Quiz[], Error>({
    queryKey: ["/api/quizzes"],
  });
}

export function useSubmitQuiz(quizId: number) {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (answers: QuizAnswer[]) => {
      const res = await apiRequest("POST", `/api/quiz/${quizId}/submit`, answers);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      toast({
        title: "Quiz submitted!",
        description: "Your answers have been recorded.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit quiz",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
