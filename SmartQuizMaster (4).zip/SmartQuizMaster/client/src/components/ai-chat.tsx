import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAIChat } from "@/hooks/use-ai-chat";
import { Loader2, Send, AlertCircle, RefreshCw } from "lucide-react";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export function AIChat() {
  const [message, setMessage] = useState("");
  const [conversation, setConversation] = useState<Array<{ role: "user" | "ai"; content: string }>>([]);
  const chatMutation = useAIChat();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!message.trim() || chatMutation.isPending) return;

    const userMessage = message;
    setMessage("");
    setConversation(prev => [...prev, { role: "user", content: userMessage }]);

    try {
      const response = await chatMutation.mutateAsync(userMessage);
      setConversation(prev => [...prev, { role: "ai", content: response.response }]);
    } catch (error) {
      // Error is handled by the mutation's onError callback
      // The error toast will be shown automatically
    }
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle>AI Tutor Chat</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-4 mb-4">
          {chatMutation.isError && (
            <Alert variant="destructive" className="mb-4 animate-in fade-in-50">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription className="flex items-center justify-between">
                <span>{chatMutation.error.message}</span>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => chatMutation.reset()}
                  className="shadow-sm hover:shadow-md transition-shadow"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {conversation.map((msg, i) => (
            <div
              key={i}
              className={`flex ${
                msg.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[80%] p-3 rounded-lg ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "bg-muted shadow-sm"
                } transition-all hover:shadow-lg`}
              >
                {msg.content}
              </div>
            </div>
          ))}
          {chatMutation.isPending && (
            <div className="flex justify-start">
              <div className="bg-muted p-3 rounded-lg shadow-sm">
                <Loader2 className="h-5 w-5 animate-spin" />
              </div>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask your question..."
            className="flex-1 shadow-sm focus:shadow-md transition-shadow"
            rows={2}
            disabled={chatMutation.isPending}
          />
          <Button 
            type="submit" 
            disabled={chatMutation.isPending || message.trim().length === 0}
            className="shadow-sm hover:shadow-md transition-all bg-gradient-to-r from-primary/90 to-primary"
          >
            {chatMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}