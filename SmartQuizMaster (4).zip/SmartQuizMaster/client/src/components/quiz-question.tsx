import { Question } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface QuizQuestionProps {
  question: Question;
  selectedAnswer?: string;
  onAnswer: (answer: string) => void;
  showCorrect?: boolean;
}

export function QuizQuestion({
  question,
  selectedAnswer,
  onAnswer,
  showCorrect,
}: QuizQuestionProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">{question.text}</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={selectedAnswer}
          onValueChange={onAnswer}
          className="space-y-4"
        >
          {question.options.map((option, index) => (
            <div
              key={index}
              className={`flex items-center space-x-2 p-2 rounded-lg border ${
                showCorrect &&
                option === question.correctAnswer &&
                "bg-green-100 border-green-500"
              } ${
                showCorrect &&
                selectedAnswer === option &&
                option !== question.correctAnswer &&
                "bg-red-100 border-red-500"
              }`}
            >
              <RadioGroupItem value={option} id={`option-${index}`} />
              <Label htmlFor={`option-${index}`} className="flex-grow">
                {option}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
}
