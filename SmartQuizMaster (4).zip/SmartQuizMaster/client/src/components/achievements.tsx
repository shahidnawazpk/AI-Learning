import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Star, Award } from "lucide-react";

interface AchievementsProps {
  achievements: string[];
  totalScore: number;
  quizzesTaken: number;
}

const achievementIcons = {
  "First Quiz": Trophy,
  "Perfect Score": Star,
  "Quiz Master": Award,
};

export function Achievements({ achievements, totalScore, quizzesTaken }: AchievementsProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Your Achievements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => {
              const Icon = achievementIcons[achievement as keyof typeof achievementIcons] || Trophy;
              return (
                <div
                  key={achievement}
                  className="flex items-center space-x-3 p-3 bg-accent/10 rounded-lg"
                >
                  <Icon className="h-6 w-6 text-primary" />
                  <span>{achievement}</span>
                </div>
              );
            })}
          </div>
          
          <div className="mt-6 grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <h4 className="text-2xl font-bold text-primary">{totalScore}</h4>
              <p className="text-sm text-muted-foreground">Total Score</p>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <h4 className="text-2xl font-bold text-primary">{quizzesTaken}</h4>
              <p className="text-sm text-muted-foreground">Quizzes Taken</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
