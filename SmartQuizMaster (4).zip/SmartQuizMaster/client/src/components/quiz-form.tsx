import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { quizSettingsSchema, type QuizSettings } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useCreateQuiz } from "@/hooks/use-quiz";
import { useLocation } from "wouter";
import { Loader2, AlertCircle, RefreshCw, BookOpen } from "lucide-react";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const subjects = [
  "Mathematics",
  "Science",
  "History",
  "Geography",
  "Literature",
  "Computer Science",
];

export function QuizForm() {
  const [, setLocation] = useLocation();
  const createQuiz = useCreateQuiz();

  const form = useForm<QuizSettings>({
    resolver: zodResolver(quizSettingsSchema),
    defaultValues: {
      subject: "",
      questionCount: 10,
    },
  });

  async function onSubmit(data: QuizSettings) {
    try {
      const quiz = await createQuiz.mutateAsync(data);
      setLocation(`/quiz/${quiz.id}`);
    } catch (error) {
      //More specific error handling would go here.  For example, checking for 429 errors.
      form.reset(form.getValues());
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          Create New Quiz
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {createQuiz.isError && (
              <Alert variant="destructive" className="animate-in fade-in-50">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Failed to Create Quiz</AlertTitle>
                <AlertDescription className="flex items-center justify-between">
                  <span>
                    {createQuiz.error?.message ||
                      "An unexpected error occurred. Please try again later."}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      createQuiz.reset();
                      form.handleSubmit(onSubmit)();
                    }}
                    className="shadow-sm hover:shadow-md transition-shadow"
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Try Again
                  </Button>
                </AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="subject"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Subject</FormLabel>
                  <FormControl>
                    <select
                      {...field}
                      className="w-full p-2 border rounded-md bg-background shadow-sm focus:shadow-md transition-shadow"
                      disabled={createQuiz.isPending}
                    >
                      <option value="">Select a subject</option>
                      {subjects.map((subject) => (
                        <option key={subject} value={subject}>
                          {subject}
                        </option>
                      ))}
                    </select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="questionCount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Number of Questions</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      {...field}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                      min={1}
                      max={20}
                      disabled={createQuiz.isPending}
                      className="shadow-sm focus:shadow-md transition-shadow"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full shadow-sm hover:shadow-md transition-all bg-gradient-to-r from-primary/90 to-primary"
              disabled={createQuiz.isPending}
            >
              {createQuiz.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating Quiz...
                </>
              ) : (
                "Start Quiz"
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}