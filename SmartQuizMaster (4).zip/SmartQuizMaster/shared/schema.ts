import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  achievements: jsonb("achievements").default([]).notNull(),
  totalScore: integer("total_score").default(0).notNull(),
  quizzesTaken: integer("quizzes_taken").default(0).notNull(),
});

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  subject: text("subject").notNull(),
  score: integer("score").notNull(),
  questions: jsonb("questions").notNull(),
  answers: jsonb("answers").notNull(),
  completed: boolean("completed").default(false).notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const quizSettingsSchema = z.object({
  subject: z.string().min(1),
  questionCount: z.number().min(1).max(20),
});

export const quizAnswerSchema = z.object({
  questionId: z.number(),
  selectedAnswer: z.string(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Quiz = typeof quizzes.$inferSelect;
export type QuizSettings = z.infer<typeof quizSettingsSchema>;
export type QuizAnswer = z.infer<typeof quizAnswerSchema>;

export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: string;
}
