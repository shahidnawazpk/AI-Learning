import session from "express-session";
import createMemoryStore from "memorystore";
import { User, Quiz, InsertUser, Question } from "@shared/schema";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserAchievements(userId: number, achievements: string[]): Promise<void>;
  updateUserStats(userId: number, score: number): Promise<void>;
  createQuiz(userId: number, subject: string, questions: Question[]): Promise<Quiz>;
  getQuiz(id: number): Promise<Quiz | undefined>;
  completeQuiz(id: number, answers: string[], score: number): Promise<void>;
  getUserQuizzes(userId: number): Promise<Quiz[]>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private quizzes: Map<number, Quiz>;
  private currentUserId: number;
  private currentQuizId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.quizzes = new Map();
    this.currentUserId = 1;
    this.currentQuizId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      achievements: [],
      totalScore: 0,
      quizzesTaken: 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserAchievements(userId: number, achievements: string[]): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    user.achievements = achievements;
    this.users.set(userId, user);
  }

  async updateUserStats(userId: number, score: number): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    user.totalScore += score;
    user.quizzesTaken += 1;
    this.users.set(userId, user);
  }

  async createQuiz(userId: number, subject: string, questions: Question[]): Promise<Quiz> {
    const id = this.currentQuizId++;
    const quiz: Quiz = {
      id,
      userId,
      subject,
      score: 0,
      questions,
      answers: [],
      completed: false,
      createdAt: new Date().toISOString(),
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  async getQuiz(id: number): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async completeQuiz(id: number, answers: string[], score: number): Promise<void> {
    const quiz = await this.getQuiz(id);
    if (!quiz) throw new Error("Quiz not found");
    quiz.answers = answers;
    quiz.score = score;
    quiz.completed = true;
    this.quizzes.set(id, quiz);
    await this.updateUserStats(quiz.userId, score);
  }

  async getUserQuizzes(userId: number): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(
      (quiz) => quiz.userId === userId,
    );
  }
}

export const storage = new MemStorage();
