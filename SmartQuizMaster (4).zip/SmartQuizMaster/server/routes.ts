import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { generateQuestions, getChatResponse } from "./ai";
import { quizSettingsSchema, quizAnswerSchema, type Question } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Quiz routes
  app.post("/api/quiz", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const result = quizSettingsSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    try {
      const questions = await generateQuestions(
        result.data.subject,
        result.data.questionCount
      );
      const quiz = await storage.createQuiz(req.user!.id, result.data.subject, questions);
      res.json(quiz);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/quiz/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const quiz = await storage.getQuiz(parseInt(req.params.id));
    if (!quiz) return res.status(404).json({ message: "Quiz not found" });
    if (quiz.userId !== req.user!.id) return res.sendStatus(403);
    res.json(quiz);
  });

  app.post("/api/quiz/:id/submit", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const quiz = await storage.getQuiz(parseInt(req.params.id));
    if (!quiz) return res.status(404).json({ message: "Quiz not found" });
    if (quiz.userId !== req.user!.id) return res.sendStatus(403);
    if (quiz.completed) return res.status(400).json({ message: "Quiz already completed" });

    const result = quizAnswerSchema.array().safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const answers = result.data.map(a => a.selectedAnswer);
    const questions = quiz.questions as Question[];
    const score = questions.reduce((acc: number, q: Question, i: number) => {
      return acc + (q.correctAnswer === answers[i] ? 1 : 0);
    }, 0);

    await storage.completeQuiz(quiz.id, answers, score);

    // Update user statistics
    const user = req.user!;
    user.quizzesTaken = (user.quizzesTaken || 0) + 1;
    user.totalScore = (user.totalScore || 0) + score;

    if (score === questions.length) {
      user.achievements = [...(user.achievements || []), 'PERFECT_SCORE'];
    }
    if ((user.quizzesTaken || 0) >= 5) {
      user.achievements = [...(user.achievements || []), 'QUIZ_MASTER'];
    }

    await storage.updateUser(user.id, {
      quizzesTaken: user.quizzesTaken,
      totalScore: user.totalScore,
      achievements: user.achievements
    });

    res.json({ score });
  });

  app.get("/api/quizzes", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const quizzes = await storage.getUserQuizzes(req.user!.id);
    res.json(quizzes);
  });

  // AI Chat route
  app.post("/api/chat", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { message } = req.body;
    if (!message || typeof message !== "string") {
      return res.status(400).json({ message: "Invalid message" });
    }

    try {
      const response = await getChatResponse(message);
      res.json({ response });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}