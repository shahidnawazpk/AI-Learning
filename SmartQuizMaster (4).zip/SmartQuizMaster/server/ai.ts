import OpenAI from "openai";
import { Question } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const MAX_RETRIES = 3;
const BASE_DELAY = 2000; // 2 seconds
const QUEUE_INTERVAL = 1000; // 1 second between requests

// Simple request queue to manage API calls
class RequestQueue {
  private queue: Array<() => Promise<any>> = [];
  private processing = false;

  async add<T>(fn: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      this.queue.push(async () => {
        try {
          const result = await fn();
          resolve(result);
        } catch (error) {
          reject(error);
        }
      });
      this.process();
    });
  }

  private async process() {
    if (this.processing || this.queue.length === 0) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const task = this.queue.shift()!;
      await task();
      await new Promise(resolve => setTimeout(resolve, QUEUE_INTERVAL));
    }

    this.processing = false;
  }
}

const requestQueue = new RequestQueue();

async function retry<T>(fn: () => Promise<T>, retries = MAX_RETRIES): Promise<T> {
  for (let i = 0; i < retries; i++) {
    try {
      return await requestQueue.add(fn);
    } catch (error: any) {
      if (i === retries - 1 || error?.status !== 429) {
        throw error;
      }
      const delay = BASE_DELAY * Math.pow(2, i); // Exponential backoff
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw new Error("Max retries reached");
}

// Fallback questions when API is unavailable
const fallbackQuestions = {
  "History": [
    {
      id: 1,
      text: "Who was the first President of the United States?",
      options: ["George Washington", "Thomas Jefferson", "John Adams", "Benjamin Franklin"],
      correctAnswer: "George Washington"
    },
    // Add more fallback questions...
  ],
  "Mathematics": [
    {
      id: 1,
      text: "What is 2 + 2?",
      options: ["3", "4", "5", "6"],
      correctAnswer: "4"
    },
    // Add more fallback questions...
  ],
  // Add more subjects...
};

export async function generateQuestions(subject: string, count: number): Promise<Question[]> {
  try {
    const response = await retry(() =>
      openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert quiz generator. Generate multiple choice questions with 4 options each. Return in JSON format with the following structure: { questions: [{ text: string, options: string[], correctAnswer: string }] }",
          },
          {
            role: "user",
            content: `Generate ${count} multiple choice questions about ${subject}. Each question should have exactly 4 options and one correct answer that must be one of the options.`,
          },
        ],
        response_format: { type: "json_object" },
      })
    );

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    const result = JSON.parse(content);
    if (!result.questions || !Array.isArray(result.questions)) {
      throw new Error("Invalid response format from AI");
    }

    return result.questions.map((q: any, index: number) => ({
      id: index + 1,
      text: q.text,
      options: q.options,
      correctAnswer: q.correctAnswer,
    }));
  } catch (error: any) {
    console.error("Error generating questions:", error);

    // Return fallback questions if available, otherwise throw error
    if (error?.status === 429 && fallbackQuestions[subject]) {
      console.log("Using fallback questions due to API rate limit");
      return fallbackQuestions[subject].slice(0, count);
    }

    if (error?.status === 429) {
      throw new Error("The AI service is temporarily unavailable. Please wait a moment and try again.");
    }
    throw new Error("Failed to generate questions. Please try again later.");
  }
}

export async function getChatResponse(message: string): Promise<string> {
  try {
    const response = await retry(() =>
      openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a helpful AI tutor that assists students with their questions. Provide clear, concise explanations.",
          },
          {
            role: "user",
            content: message,
          },
        ],
      })
    );

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response generated");
    }

    return content;
  } catch (error: any) {
    console.error("Error getting chat response:", error);
    if (error?.status === 429) {
      throw new Error("The AI tutor is temporarily unavailable. Please wait a moment and try again.");
    }
    throw new Error("Failed to get a response. Please try again later.");
  }
}