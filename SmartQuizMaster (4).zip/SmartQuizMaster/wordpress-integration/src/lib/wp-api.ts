import { Quiz, QuizSettings, Question } from "@shared/schema";

declare global {
  interface Window {
    aqmSettings: {
      apiUrl: string;
      nonce: string;
    };
    wpApiSettings?: {
      user?: {
        id: number;
        username: string;
      };
    };
  }
}

const BASE_URL = window.aqmSettings?.apiUrl || '/wp-json/ai-quiz-master/v1';

async function apiRequest(endpoint: string, options: RequestInit = {}) {
    const headers = {
        'Content-Type': 'application/json',
        'X-WP-Nonce': window.aqmSettings?.nonce || '',
        ...options.headers,
    };

    const response = await fetch(`${BASE_URL}${endpoint}`, {
        ...options,
        headers,
        credentials: 'same-origin',
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'API request failed');
    }

    return response;
}

export async function createQuiz(settings: QuizSettings): Promise<Quiz> {
    const response = await apiRequest('/quiz', {
        method: 'POST',
        body: JSON.stringify(settings),
    });
    return response.json();
}

export async function submitQuiz(quizId: number, answers: string[]): Promise<void> {
    await apiRequest(`/quiz/${quizId}/submit`, {
        method: 'POST',
        body: JSON.stringify({ answers }),
    });
}

export async function getQuizzes(): Promise<Quiz[]> {
    const response = await apiRequest('/quizzes');
    return response.json();
}

export async function getChatResponse(message: string): Promise<string> {
    const response = await apiRequest('/chat', {
        method: 'POST',
        body: JSON.stringify({ message }),
    });
    const data = await response.json();
    return data.response;
}

// WordPress specific authentication
export function isUserLoggedIn(): boolean {
    return !!window.wpApiSettings?.user?.id;
}

export function getCurrentUser() {
    return window.wpApiSettings?.user;
}