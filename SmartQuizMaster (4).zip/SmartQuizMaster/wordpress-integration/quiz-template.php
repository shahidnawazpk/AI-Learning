<?php
/**
 * Template Name: Quiz Application
 */

get_header(); ?>

<div id="ai-quiz-master-root"></div>

<?php
get_footer();