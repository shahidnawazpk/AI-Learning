# AI Quiz Master WordPress Plugin Installation Guide

## Step-by-Step Installation

### 1. Prepare Your WordPress Site
- Ensure you have WordPress 5.8 or higher installed
- Make sure you have an active OpenAI API key
- Verify PHP 7.4 or higher is installed

### 2. Install the Plugin
1. Log in to your WordPress admin panel
2. Go to Plugins > Add New
3. Click the "Upload Plugin" button at the top
4. Choose the downloaded `ai-quiz-master.zip` file
5. Click "Install Now"
6. After installation completes, click "Activate Plugin"

### 3. Configure the Plugin
1. Go to Settings > AI Quiz Master
2. Enter your OpenAI API key in the settings page
3. Click "Save Changes"

### 4. Create a Quiz Page
1. Go to Pages > Add New
2. Give your page a title (e.g., "Take a Quiz")
3. In the Page Attributes box (right sidebar):
   - Set Template to "Quiz Application"
4. Click "Publish"

### 5. Set Up the Frontend
1. Go to the plugin directory: `wp-content/plugins/ai-quiz-master`
2. Open terminal/command prompt in this directory
3. Run the following commands:
   ```bash
   npm install
   npm run build
   ```

### 6. Verify Installation
1. Visit your quiz page
2. Verify that you see the quiz interface
3. Try creating a new quiz
4. Test the AI chat feature

## Troubleshooting

### Common Issues

1. **White Screen / No Quiz Interface**
   - Check if JavaScript is enabled in your browser
   - Verify that the build files exist in `wp-content/plugins/ai-quiz-master/build/`
   - Check browser console for errors

2. **API Errors**
   - Verify your OpenAI API key in Settings > AI Quiz Master
   - Check if your API key has sufficient credits
   - Look for error messages in WordPress debug log

3. **Quiz Not Working**
   - Ensure you're logged into WordPress
   - Check if your user has correct permissions
   - Verify WordPress REST API is accessible

4. **Build Errors**
   - Make sure Node.js 18+ is installed
   - Clear npm cache: `npm cache clean --force`
   - Delete `node_modules` and run `npm install` again

## Support

If you encounter issues:
1. Check the WordPress debug log
2. Verify PHP error logs
3. Contact your hosting provider for server-related issues
4. Submit issues on our support forum

## Requirements

- WordPress 5.8+
- PHP 7.4+
- Node.js 18+
- MySQL 5.7+ or MariaDB 10.3+
- OpenAI API key with active subscription

## Security Notes

- Keep your OpenAI API key secure
- Regularly update WordPress and all plugins
- Use HTTPS for your WordPress site
- Implement proper user role management