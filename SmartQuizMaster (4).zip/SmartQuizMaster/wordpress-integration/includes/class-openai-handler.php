<?php
/**
 * OpenAI API Handler with request queue and retry mechanism
 */
class OpenAI_Handler {
    private static $instance = null;
    private $queue = array();
    private $processing = false;
    private $max_retries = 3;
    private $base_delay = 2000; // 2 seconds
    private $queue_interval = 1000; // 1 second

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function make_request($callback) {
        return $this->add_to_queue($callback);
    }

    private function add_to_queue($callback) {
        $this->queue[] = $callback;
        return $this->process_queue();
    }

    private function process_queue() {
        if ($this->processing || empty($this->queue)) {
            return null;
        }

        $this->processing = true;
        $result = null;
        $error = null;

        while (!empty($this->queue)) {
            $callback = array_shift($this->queue);
            
            for ($i = 0; $i < $this->max_retries; $i++) {
                try {
                    $result = $callback();
                    break;
                } catch (Exception $e) {
                    if ($i === $this->max_retries - 1 || 
                        !strpos($e->getMessage(), '429')) {
                        $error = $e;
                        break;
                    }
                    // Exponential backoff
                    $delay = $this->base_delay * pow(2, $i);
                    usleep($delay * 1000); // Convert to microseconds
                }
            }

            // Wait between requests
            usleep($this->queue_interval * 1000);
        }

        $this->processing = false;

        if ($error) {
            throw $error;
        }

        return $result;
    }
}

// Helper function to get OpenAI client with proper API key
function get_openai_client() {
    $api_key = get_option('aqm_openai_api_key');
    if (!$api_key) {
        throw new Exception('OpenAI API key not configured');
    }
    return new OpenAI(['api_key' => $api_key]);
}
