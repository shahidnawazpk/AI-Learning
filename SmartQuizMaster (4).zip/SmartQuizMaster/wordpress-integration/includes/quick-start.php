<?php
/**
 * Quick Start Guide displayed after plugin activation
 */

function aqm_display_quick_start() {
    // Only show this notice to admins and only once
    if (!current_user_can('manage_options') || get_option('aqm_quick_start_shown')) {
        return;
    }
    ?>
    <div class="notice notice-info is-dismissible">
        <h2>🎉 Welcome to AI Quiz Master!</h2>
        <p>Follow these quick steps to get started:</p>
        <ol>
            <li><a href="<?php echo admin_url('options-general.php?page=ai-quiz-master'); ?>">Configure your OpenAI API key</a></li>
            <li>Create a new page and select "Quiz Application" template</li>
            <li>Run <code>npm install && npm run build</code> in the plugin directory</li>
        </ol>
        <p>Need help? Check the <a href="<?php echo plugins_url('README.md', dirname(__FILE__)); ?>">installation guide</a>.</p>
    </div>
    <?php
    update_option('aqm_quick_start_shown', true);
}
add_action('admin_notices', 'aqm_display_quick_start');
