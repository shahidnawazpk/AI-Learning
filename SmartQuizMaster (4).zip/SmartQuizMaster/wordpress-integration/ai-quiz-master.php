<?php
/**
 * Plugin Name: AI Quiz Master
 * Description: AI-powered quiz system with OpenAI integration
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: ai-quiz-master
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AQM_VERSION', '1.0.0');
define('AQM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AQM_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load dependencies
require_once AQM_PLUGIN_DIR . 'includes/class-openai-handler.php';
require_once AQM_PLUGIN_DIR . 'includes/quick-start.php';

// Initialize the plugin
class AIQuizMaster {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Check requirements
        if ($this->check_requirements()) {
            $this->init_hooks();
        }
    }

    private function check_requirements() {
        $required_php_version = '7.4';
        $required_wp_version = '5.8';

        if (version_compare(PHP_VERSION, $required_php_version, '<')) {
            add_action('admin_notices', function() use ($required_php_version) {
                ?>
                <div class="notice notice-error">
                    <p><?php printf(__('AI Quiz Master requires PHP %s or higher.', 'ai-quiz-master'), $required_php_version); ?></p>
                </div>
                <?php
            });
            return false;
        }

        if (version_compare(get_bloginfo('version'), $required_wp_version, '<')) {
            add_action('admin_notices', function() use ($required_wp_version) {
                ?>
                <div class="notice notice-error">
                    <p><?php printf(__('AI Quiz Master requires WordPress %s or higher.', 'ai-quiz-master'), $required_wp_version); ?></p>
                </div>
                <?php
            });
            return false;
        }

        return true;
    }

    private function init_hooks() {
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('init', array($this, 'register_post_types'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_post_types() {
        register_post_type('quiz', array(
            'labels' => array(
                'name' => __('Quizzes', 'ai-quiz-master'),
                'singular_name' => __('Quiz', 'ai-quiz-master'),
            ),
            'public' => true,
            'show_in_rest' => true,
            'supports' => array('title', 'editor', 'custom-fields'),
        ));
    }

    public function add_admin_menu() {
        add_options_page(
            __('AI Quiz Master Settings', 'ai-quiz-master'),
            __('AI Quiz Master', 'ai-quiz-master'),
            'manage_options',
            'ai-quiz-master',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('ai_quiz_master', 'aqm_openai_api_key');

        add_settings_section(
            'aqm_api_settings',
            __('API Settings', 'ai-quiz-master'),
            null,
            'ai-quiz-master'
        );

        add_settings_field(
            'aqm_openai_api_key',
            __('OpenAI API Key', 'ai-quiz-master'),
            array($this, 'render_api_key_field'),
            'ai-quiz-master',
            'aqm_api_settings'
        );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('ai_quiz_master');
                do_settings_sections('ai-quiz-master');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function render_api_key_field() {
        $api_key = get_option('aqm_openai_api_key');
        ?>
        <input type="password" 
               name="aqm_openai_api_key" 
               value="<?php echo esc_attr($api_key); ?>" 
               class="regular-text"
        />
        <p class="description">
            <?php _e('Enter your OpenAI API key. Get one at https://platform.openai.com/api-keys', 'ai-quiz-master'); ?>
        </p>
        <?php
    }

    public function register_rest_routes() {
        register_rest_route('ai-quiz-master/v1', '/quiz', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_quiz'),
            'permission_callback' => function() {
                return is_user_logged_in();
            }
        ));

        register_rest_route('ai-quiz-master/v1', '/chat', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_chat'),
            'permission_callback' => function() {
                return is_user_logged_in();
            }
        ));
    }

    public function create_quiz($request) {
        $params = $request->get_params();
        $user_id = get_current_user_id();

        if (!get_option('aqm_openai_api_key')) {
            return new WP_Error('no_api_key', 'OpenAI API key is not configured', array('status' => 500));
        }

        try {
            $questions = $this->generate_questions($params['subject'], $params['questionCount']);

            $quiz_id = wp_insert_post(array(
                'post_type' => 'quiz',
                'post_title' => $params['subject'] . ' Quiz',
                'post_status' => 'publish',
                'post_author' => $user_id,
            ));

            update_post_meta($quiz_id, 'questions', $questions);

            return rest_ensure_response(array(
                'id' => $quiz_id,
                'subject' => $params['subject'],
                'questions' => $questions,
            ));
        } catch (Exception $e) {
            return new WP_Error('quiz_creation_failed', $e->getMessage(), array('status' => 500));
        }
    }

    private function generate_questions($subject, $count) {
        $handler = OpenAI_Handler::get_instance();

        return $handler->make_request(function() use ($subject, $count) {
            $openai = get_openai_client();

            $response = $openai->chat->create([
                'model' => 'gpt-4o',
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are an expert quiz generator. Generate multiple choice questions with 4 options each.',
                    ],
                    [
                        'role' => 'user',
                        'content' => "Generate {$count} multiple choice questions about {$subject}.",
                    ],
                ],
                'response_format' => ['type' => 'json_object'],
            ]);

            $content = $response->choices[0]->message->content;
            if (!$content) {
                throw new Exception('No response generated');
            }

            return json_decode($content, true);
        });
    }

    public function handle_chat($request) {
        if (!get_option('aqm_openai_api_key')) {
            return new WP_Error('no_api_key', 'OpenAI API key is not configured', array('status' => 500));
        }

        $message = $request->get_param('message');
        if (!$message || !is_string($message)) {
            return new WP_Error('invalid_message', 'Message is required', array('status' => 400));
        }

        try {
            $handler = OpenAI_Handler::get_instance();

            $response = $handler->make_request(function() use ($message) {
                $openai = get_openai_client();

                $response = $openai->chat->create([
                    'model' => 'gpt-4o',
                    'messages' => [
                        [
                            'role' => 'system',
                            'content' => 'You are a helpful AI tutor that assists students with their questions. Provide clear, concise explanations.',
                        ],
                        [
                            'role' => 'user',
                            'content' => $message,
                        ],
                    ],
                ]);

                $content = $response->choices[0]->message->content;
                if (!$content) {
                    throw new Exception('No response generated');
                }

                return $content;
            });

            return rest_ensure_response(array('response' => $response));
        } catch (Exception $e) {
            return new WP_Error(
                'chat_failed',
                $e->getMessage(),
                array('status' => 500)
            );
        }
    }

    public function enqueue_scripts() {
        if (!is_page_template('quiz-template.php')) {
            return;
        }

        wp_enqueue_script(
            'ai-quiz-master',
            AQM_PLUGIN_URL . 'build/index.js',
            array('wp-element'),
            AQM_VERSION,
            true
        );

        wp_localize_script('ai-quiz-master', 'aqmSettings', array(
            'apiUrl' => rest_url('ai-quiz-master/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
        ));
    }
}

// Initialize the plugin
function ai_quiz_master_init() {
    AIQuizMaster::get_instance();
}
add_action('plugins_loaded', 'ai_quiz_master_init');

// Activation hook
register_activation_hook(__FILE__, function() {
    // Create necessary database tables
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    // Create quizzes table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aqm_quizzes (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        subject varchar(255) NOT NULL,
        questions longtext NOT NULL,
        answers longtext,
        score int(11),
        completed tinyint(1) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    dbDelta($sql);
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Clean up any plugin-specific options
    delete_option('aqm_quick_start_shown');
});